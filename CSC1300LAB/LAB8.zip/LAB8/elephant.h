#ifndef ELEPHANT_H
#define ELEPHANT_H

#include <iostream>
#include <string>
using namespace std;
void GETELEPHANTDATA(float foodAmt[], string elephantName[]);
void GETSTATS(float foodAmt[], float& foodTotal, float& foodAverage, int& elePig);
#endif