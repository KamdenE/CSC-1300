/*******************************************************************
	Title: 		lab3b.cpp
	Author: 	Sherif Abdelfattah, MODIFIED BY ________
	Date:  		February 06, 2022, MODIFIED ON _________
	Purpose: 	Practice with random numbers, string, and branching
********************************************************************/

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{
	int randomNum;
	string name, anotherName, location, food;
	string original;
	
	/* !!!!! ADD THE STATEMENT HERE THAT WILL SEED THE RANDOM NUMBER GENERATOR BASED ON COMPUTER TIME */
	srand(time(0));
	
	cout << "Good afternoon!  Please enter the following information:\n\n";
	cout << "YOUR NAME:  ";
	getline(cin, name);
	cout << "ANOTHER PERSON\'s NAME:  ";
	getline(cin, anotherName);
	cout << "LOCATION NAME:  ";
	getline(cin, location);
	cout << "FOOD NAME:  ";
	getline(cin, food);
	
	cout << endl;
	
	/* !!!!! GENERATE A RANDOM NUMBER THAT IS EITHER A 1 OR 2 AND SAVE IN randomNum1 */
	
	
	
	/* !!!!!COMPLETE THE FOLLOWING if/else if/else block so that if randomNum is 
		equal to 1, it will print out the message of the sample output 1
		Otherwise, if randomNum is to 2, it will print out the message of the sample output 2

	*/
	
	
	cout << original;
	
	
	
	cout << endl;
	return 0;
}