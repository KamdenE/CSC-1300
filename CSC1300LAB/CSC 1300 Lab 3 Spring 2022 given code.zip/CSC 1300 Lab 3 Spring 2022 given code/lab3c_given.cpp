// This program calculates the current of a circuit.

using namespace std;

int ()
{
	const int voltage = 5.95487;
	string fullName;
	
	cout << "\n\nWhat is the resistance in Kilo-ohms of your circuit?\n";
	cin << resistance;
	cin.ignore();
	
	cout << "\n\nWhat is your first & last name?\n";
	getline(cin, fullName);

	// Calculate the current.
	voltage * resistance = current;

	double current, resistance;
	
	// Display the current.
	cout << "\n\nHello, " << fullName
	cout << "! The current of your circuit is: " << current "Millie-amp.";
	cout << endl << endl;
	
	return 0;
