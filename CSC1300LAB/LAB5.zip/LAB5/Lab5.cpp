/*  File Name: LAB5.cpp
    Author: Kamden Edens
    Date: February 26, 2022
    Purpose: To display code on the Edu board
*/
/*#include "mbed.h" 
#include "TTU_X031.h" 
#include "SevenSegmentLED.h" 
#include "TextLCD.h" 
 
TextLCD lcd(TextLCD::LCD_CURSOR_ON_BLINKING_ON); 

int main(){ 
 //clears screen and prints name
 lcd.cls(); 
 lcd.printf("Hello! My name ");
 lcd.printf(" is Kamden");
 wait_ms(3000); // time delay of 3 seconds
 lcd.cls();
 lcd.printf("My major is ");
 wait_ms(1000); // time delay of 1 second then clears screen
 lcd.cls();
 lcd.printf("Electrical \nEngineering ");
 wait_ms(3000); // time delay of 3 seconds again
 lcd.cls();
 lcd.printf("Goodbye!"); // is left on the screen after the program ends ends
 return 0; 
}*/